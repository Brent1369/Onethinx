/*******************************************************************************
* File Name: cycfg_pins.c
*
* Description:
* Pin configuration
* This file was automatically generated and should not be modified.
* Tools Package 2.4.0.5972
* psoc6pdl 1.3.1.1499
* personalities 1.0.0.0
* udd 1.1.2.62
*
********************************************************************************
* Copyright 2022 Cypress Semiconductor Corporation (an Infineon company) or
* an affiliate of Cypress Semiconductor Corporation.
* SPDX-License-Identifier: Apache-2.0
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
********************************************************************************/

#include "cycfg_pins.h"

const cy_stc_gpio_pin_config_t ioss_0_port_0_pin_0_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = ioss_0_port_0_pin_0_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .intMask = 0UL,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
    .driveSel = CY_GPIO_DRIVE_1_2,
    .vregEn = 0UL,
    .ibufMode = 0UL,
    .vtripSel = 0UL,
    .vrefSel = 0UL,
    .vohSel = 0UL,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t ioss_0_port_0_pin_0_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = ioss_0_port_0_pin_0_PORT_NUM,
        .channel_num = ioss_0_port_0_pin_0_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t ioss_0_port_0_pin_1_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = ioss_0_port_0_pin_1_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .intMask = 0UL,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
    .driveSel = CY_GPIO_DRIVE_1_2,
    .vregEn = 0UL,
    .ibufMode = 0UL,
    .vtripSel = 0UL,
    .vrefSel = 0UL,
    .vohSel = 0UL,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t ioss_0_port_0_pin_1_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = ioss_0_port_0_pin_1_PORT_NUM,
        .channel_num = ioss_0_port_0_pin_1_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t PIN_BUTTON_config = 
{
    .outVal = 0,
    .driveMode = CY_GPIO_DM_PULLDOWN,
    .hsiom = PIN_BUTTON_HSIOM,
    .intEdge = CY_GPIO_INTR_RISING,
    .intMask = 1UL,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
    .driveSel = CY_GPIO_DRIVE_1_2,
    .vregEn = 0UL,
    .ibufMode = 0UL,
    .vtripSel = 0UL,
    .vrefSel = 0UL,
    .vohSel = 0UL,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t PIN_BUTTON_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = PIN_BUTTON_PORT_NUM,
        .channel_num = PIN_BUTTON_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t ioss_0_port_10_pin_0_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_HIGHZ,
    .hsiom = ioss_0_port_10_pin_0_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .intMask = 0UL,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
    .driveSel = CY_GPIO_DRIVE_1_2,
    .vregEn = 0UL,
    .ibufMode = 0UL,
    .vtripSel = 0UL,
    .vrefSel = 0UL,
    .vohSel = 0UL,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t ioss_0_port_10_pin_0_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = ioss_0_port_10_pin_0_PORT_NUM,
        .channel_num = ioss_0_port_10_pin_0_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t ioss_0_port_10_pin_1_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG_IN_OFF,
    .hsiom = ioss_0_port_10_pin_1_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .intMask = 0UL,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
    .driveSel = CY_GPIO_DRIVE_1_2,
    .vregEn = 0UL,
    .ibufMode = 0UL,
    .vtripSel = 0UL,
    .vrefSel = 0UL,
    .vohSel = 0UL,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t ioss_0_port_10_pin_1_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = ioss_0_port_10_pin_1_PORT_NUM,
        .channel_num = ioss_0_port_10_pin_1_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t Sensor1_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = Sensor1_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .intMask = 0UL,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
    .driveSel = CY_GPIO_DRIVE_1_2,
    .vregEn = 0UL,
    .ibufMode = 0UL,
    .vtripSel = 0UL,
    .vrefSel = 0UL,
    .vohSel = 0UL,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t Sensor1_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = Sensor1_PORT_NUM,
        .channel_num = Sensor1_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t Sensor2_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = Sensor2_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .intMask = 0UL,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
    .driveSel = CY_GPIO_DRIVE_1_2,
    .vregEn = 0UL,
    .ibufMode = 0UL,
    .vtripSel = 0UL,
    .vrefSel = 0UL,
    .vohSel = 0UL,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t Sensor2_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = Sensor2_PORT_NUM,
        .channel_num = Sensor2_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t Sensor3_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = Sensor3_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .intMask = 0UL,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
    .driveSel = CY_GPIO_DRIVE_1_2,
    .vregEn = 0UL,
    .ibufMode = 0UL,
    .vtripSel = 0UL,
    .vrefSel = 0UL,
    .vohSel = 0UL,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t Sensor3_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = Sensor3_PORT_NUM,
        .channel_num = Sensor3_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t LED_BLUE_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG_IN_OFF,
    .hsiom = LED_BLUE_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .intMask = 0UL,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_SLOW,
    .driveSel = CY_GPIO_DRIVE_1_2,
    .vregEn = 0UL,
    .ibufMode = 0UL,
    .vtripSel = 0UL,
    .vrefSel = 0UL,
    .vohSel = 0UL,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t LED_BLUE_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = LED_BLUE_PORT_NUM,
        .channel_num = LED_BLUE_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t LED_RED_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_STRONG_IN_OFF,
    .hsiom = LED_RED_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .intMask = 0UL,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_SLOW,
    .driveSel = CY_GPIO_DRIVE_1_2,
    .vregEn = 0UL,
    .ibufMode = 0UL,
    .vtripSel = 0UL,
    .vrefSel = 0UL,
    .vohSel = 0UL,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t LED_RED_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = LED_RED_PORT_NUM,
        .channel_num = LED_RED_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t Button1_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_PULLUP_IN_OFF,
    .hsiom = Button1_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .intMask = 0UL,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
    .driveSel = CY_GPIO_DRIVE_1_2,
    .vregEn = 0UL,
    .ibufMode = 0UL,
    .vtripSel = 0UL,
    .vrefSel = 0UL,
    .vohSel = 0UL,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t Button1_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = Button1_PORT_NUM,
        .channel_num = Button1_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t Button2_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_PULLUP_IN_OFF,
    .hsiom = Button2_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .intMask = 0UL,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
    .driveSel = CY_GPIO_DRIVE_1_2,
    .vregEn = 0UL,
    .ibufMode = 0UL,
    .vtripSel = 0UL,
    .vrefSel = 0UL,
    .vohSel = 0UL,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t Button2_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = Button2_PORT_NUM,
        .channel_num = Button2_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t Button3_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_ANALOG,
    .hsiom = Button3_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .intMask = 0UL,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
    .driveSel = CY_GPIO_DRIVE_1_2,
    .vregEn = 0UL,
    .ibufMode = 0UL,
    .vtripSel = 0UL,
    .vrefSel = 0UL,
    .vohSel = 0UL,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t Button3_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = Button3_PORT_NUM,
        .channel_num = Button3_PIN,
    };
#endif //defined (CY_USING_HAL)
const cy_stc_gpio_pin_config_t Button4_config = 
{
    .outVal = 1,
    .driveMode = CY_GPIO_DM_PULLUP,
    .hsiom = Button4_HSIOM,
    .intEdge = CY_GPIO_INTR_DISABLE,
    .intMask = 0UL,
    .vtrip = CY_GPIO_VTRIP_CMOS,
    .slewRate = CY_GPIO_SLEW_FAST,
    .driveSel = CY_GPIO_DRIVE_1_2,
    .vregEn = 0UL,
    .ibufMode = 0UL,
    .vtripSel = 0UL,
    .vrefSel = 0UL,
    .vohSel = 0UL,
};
#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t Button4_obj = 
    {
        .type = CYHAL_RSC_GPIO,
        .block_num = Button4_PORT_NUM,
        .channel_num = Button4_PIN,
    };
#endif //defined (CY_USING_HAL)


void init_cycfg_pins(void)
{
    Cy_GPIO_Pin_Init(ioss_0_port_0_pin_0_PORT, ioss_0_port_0_pin_0_PIN, &ioss_0_port_0_pin_0_config);
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&ioss_0_port_0_pin_0_obj);
#endif //defined (CY_USING_HAL)

    Cy_GPIO_Pin_Init(ioss_0_port_0_pin_1_PORT, ioss_0_port_0_pin_1_PIN, &ioss_0_port_0_pin_1_config);
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&ioss_0_port_0_pin_1_obj);
#endif //defined (CY_USING_HAL)

    Cy_GPIO_Pin_Init(PIN_BUTTON_PORT, PIN_BUTTON_PIN, &PIN_BUTTON_config);
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&PIN_BUTTON_obj);
#endif //defined (CY_USING_HAL)

    Cy_GPIO_Pin_Init(ioss_0_port_10_pin_0_PORT, ioss_0_port_10_pin_0_PIN, &ioss_0_port_10_pin_0_config);
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&ioss_0_port_10_pin_0_obj);
#endif //defined (CY_USING_HAL)

    Cy_GPIO_Pin_Init(ioss_0_port_10_pin_1_PORT, ioss_0_port_10_pin_1_PIN, &ioss_0_port_10_pin_1_config);
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&ioss_0_port_10_pin_1_obj);
#endif //defined (CY_USING_HAL)

    Cy_GPIO_Pin_Init(Sensor1_PORT, Sensor1_PIN, &Sensor1_config);
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&Sensor1_obj);
#endif //defined (CY_USING_HAL)

    Cy_GPIO_Pin_Init(Sensor2_PORT, Sensor2_PIN, &Sensor2_config);
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&Sensor2_obj);
#endif //defined (CY_USING_HAL)

    Cy_GPIO_Pin_Init(Sensor3_PORT, Sensor3_PIN, &Sensor3_config);
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&Sensor3_obj);
#endif //defined (CY_USING_HAL)

    Cy_GPIO_Pin_Init(LED_BLUE_PORT, LED_BLUE_PIN, &LED_BLUE_config);
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&LED_BLUE_obj);
#endif //defined (CY_USING_HAL)

    Cy_GPIO_Pin_Init(LED_RED_PORT, LED_RED_PIN, &LED_RED_config);
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&LED_RED_obj);
#endif //defined (CY_USING_HAL)

    Cy_GPIO_Pin_Init(Button1_PORT, Button1_PIN, &Button1_config);
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&Button1_obj);
#endif //defined (CY_USING_HAL)

    Cy_GPIO_Pin_Init(Button2_PORT, Button2_PIN, &Button2_config);
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&Button2_obj);
#endif //defined (CY_USING_HAL)

    Cy_GPIO_Pin_Init(Button3_PORT, Button3_PIN, &Button3_config);
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&Button3_obj);
#endif //defined (CY_USING_HAL)

    Cy_GPIO_Pin_Init(Button4_PORT, Button4_PIN, &Button4_config);
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&Button4_obj);
#endif //defined (CY_USING_HAL)
}
