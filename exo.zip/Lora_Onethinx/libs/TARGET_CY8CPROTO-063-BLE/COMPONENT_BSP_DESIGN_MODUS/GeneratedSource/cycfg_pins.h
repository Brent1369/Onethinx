/*******************************************************************************
* File Name: cycfg_pins.h
*
* Description:
* Pin configuration
* This file was automatically generated and should not be modified.
* Tools Package 2.4.0.5972
* psoc6pdl 1.3.1.1499
* personalities 1.0.0.0
* udd 1.1.2.62
*
********************************************************************************
* Copyright 2022 Cypress Semiconductor Corporation (an Infineon company) or
* an affiliate of Cypress Semiconductor Corporation.
* SPDX-License-Identifier: Apache-2.0
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
********************************************************************************/

#if !defined(CYCFG_PINS_H)
#define CYCFG_PINS_H

#include "cycfg_notices.h"
#include "cy_gpio.h"
#if defined (CY_USING_HAL)
    #include "cyhal_hwmgr.h"
#endif //defined (CY_USING_HAL)
#include "cycfg_routing.h"

#if defined(__cplusplus)
extern "C" {
#endif

#define ioss_0_port_0_pin_0_ENABLED 1U
#define ioss_0_port_0_pin_0_PORT GPIO_PRT0
#define ioss_0_port_0_pin_0_PORT_NUM 0U
#define ioss_0_port_0_pin_0_PIN 0U
#define ioss_0_port_0_pin_0_NUM 0U
#define ioss_0_port_0_pin_0_DRIVEMODE CY_GPIO_DM_ANALOG
#define ioss_0_port_0_pin_0_INIT_DRIVESTATE 1
#ifndef ioss_0_port_0_pin_0_HSIOM
    #define ioss_0_port_0_pin_0_HSIOM HSIOM_SEL_GPIO
#endif
#define ioss_0_port_0_pin_0_IRQ ioss_interrupts_gpio_0_IRQn
#if defined (CY_USING_HAL)
    #define ioss_0_port_0_pin_0_HAL_PORT_PIN P0_0
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define ioss_0_port_0_pin_0_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define ioss_0_port_0_pin_0_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define ioss_0_port_0_pin_0_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#endif //defined (CY_USING_HAL)
#define ioss_0_port_0_pin_1_ENABLED 1U
#define ioss_0_port_0_pin_1_PORT GPIO_PRT0
#define ioss_0_port_0_pin_1_PORT_NUM 0U
#define ioss_0_port_0_pin_1_PIN 1U
#define ioss_0_port_0_pin_1_NUM 1U
#define ioss_0_port_0_pin_1_DRIVEMODE CY_GPIO_DM_ANALOG
#define ioss_0_port_0_pin_1_INIT_DRIVESTATE 1
#ifndef ioss_0_port_0_pin_1_HSIOM
    #define ioss_0_port_0_pin_1_HSIOM HSIOM_SEL_GPIO
#endif
#define ioss_0_port_0_pin_1_IRQ ioss_interrupts_gpio_0_IRQn
#if defined (CY_USING_HAL)
    #define ioss_0_port_0_pin_1_HAL_PORT_PIN P0_1
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define ioss_0_port_0_pin_1_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define ioss_0_port_0_pin_1_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define ioss_0_port_0_pin_1_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#endif //defined (CY_USING_HAL)
#define PIN_BUTTON_ENABLED 1U
#define PIN_BUTTON_PORT GPIO_PRT0
#define PIN_BUTTON_PORT_NUM 0U
#define PIN_BUTTON_PIN 4U
#define PIN_BUTTON_NUM 4U
#define PIN_BUTTON_DRIVEMODE CY_GPIO_DM_PULLDOWN
#define PIN_BUTTON_INIT_DRIVESTATE 0
#ifndef ioss_0_port_0_pin_4_HSIOM
    #define ioss_0_port_0_pin_4_HSIOM HSIOM_SEL_GPIO
#endif
#define PIN_BUTTON_HSIOM ioss_0_port_0_pin_4_HSIOM
#define PIN_BUTTON_IRQ ioss_interrupts_gpio_0_IRQn
#if defined (CY_USING_HAL)
    #define PIN_BUTTON_HAL_PORT_PIN P0_4
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define PIN_BUTTON_HAL_IRQ CYHAL_GPIO_IRQ_RISE
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define PIN_BUTTON_HAL_DIR CYHAL_GPIO_DIR_BIDIRECTIONAL 
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define PIN_BUTTON_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_PULLDOWN
#endif //defined (CY_USING_HAL)
#define ioss_0_port_10_pin_0_ENABLED 1U
#define ioss_0_port_10_pin_0_PORT GPIO_PRT10
#define ioss_0_port_10_pin_0_PORT_NUM 10U
#define ioss_0_port_10_pin_0_PIN 0U
#define ioss_0_port_10_pin_0_NUM 0U
#define ioss_0_port_10_pin_0_DRIVEMODE CY_GPIO_DM_HIGHZ
#define ioss_0_port_10_pin_0_INIT_DRIVESTATE 1
#ifndef ioss_0_port_10_pin_0_HSIOM
    #define ioss_0_port_10_pin_0_HSIOM HSIOM_SEL_GPIO
#endif
#define ioss_0_port_10_pin_0_IRQ ioss_interrupts_gpio_10_IRQn
#if defined (CY_USING_HAL)
    #define ioss_0_port_10_pin_0_HAL_PORT_PIN P10_0
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define ioss_0_port_10_pin_0_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define ioss_0_port_10_pin_0_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define ioss_0_port_10_pin_0_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_NONE
#endif //defined (CY_USING_HAL)
#define ioss_0_port_10_pin_1_ENABLED 1U
#define ioss_0_port_10_pin_1_PORT GPIO_PRT10
#define ioss_0_port_10_pin_1_PORT_NUM 10U
#define ioss_0_port_10_pin_1_PIN 1U
#define ioss_0_port_10_pin_1_NUM 1U
#define ioss_0_port_10_pin_1_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define ioss_0_port_10_pin_1_INIT_DRIVESTATE 1
#ifndef ioss_0_port_10_pin_1_HSIOM
    #define ioss_0_port_10_pin_1_HSIOM HSIOM_SEL_GPIO
#endif
#define ioss_0_port_10_pin_1_IRQ ioss_interrupts_gpio_10_IRQn
#if defined (CY_USING_HAL)
    #define ioss_0_port_10_pin_1_HAL_PORT_PIN P10_1
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define ioss_0_port_10_pin_1_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define ioss_0_port_10_pin_1_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define ioss_0_port_10_pin_1_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif //defined (CY_USING_HAL)
#define Sensor1_ENABLED 1U
#define Sensor1_PORT GPIO_PRT10
#define Sensor1_PORT_NUM 10U
#define Sensor1_PIN 2U
#define Sensor1_NUM 2U
#define Sensor1_DRIVEMODE CY_GPIO_DM_ANALOG
#define Sensor1_INIT_DRIVESTATE 1
#ifndef ioss_0_port_10_pin_2_HSIOM
    #define ioss_0_port_10_pin_2_HSIOM HSIOM_SEL_GPIO
#endif
#define Sensor1_HSIOM ioss_0_port_10_pin_2_HSIOM
#define Sensor1_IRQ ioss_interrupts_gpio_10_IRQn
#if defined (CY_USING_HAL)
    #define Sensor1_HAL_PORT_PIN P10_2
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Sensor1_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Sensor1_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Sensor1_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#endif //defined (CY_USING_HAL)
#define Sensor2_ENABLED 1U
#define Sensor2_PORT GPIO_PRT10
#define Sensor2_PORT_NUM 10U
#define Sensor2_PIN 3U
#define Sensor2_NUM 3U
#define Sensor2_DRIVEMODE CY_GPIO_DM_ANALOG
#define Sensor2_INIT_DRIVESTATE 1
#ifndef ioss_0_port_10_pin_3_HSIOM
    #define ioss_0_port_10_pin_3_HSIOM HSIOM_SEL_GPIO
#endif
#define Sensor2_HSIOM ioss_0_port_10_pin_3_HSIOM
#define Sensor2_IRQ ioss_interrupts_gpio_10_IRQn
#if defined (CY_USING_HAL)
    #define Sensor2_HAL_PORT_PIN P10_3
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Sensor2_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Sensor2_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Sensor2_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#endif //defined (CY_USING_HAL)
#define Sensor3_ENABLED 1U
#define Sensor3_PORT GPIO_PRT10
#define Sensor3_PORT_NUM 10U
#define Sensor3_PIN 4U
#define Sensor3_NUM 4U
#define Sensor3_DRIVEMODE CY_GPIO_DM_ANALOG
#define Sensor3_INIT_DRIVESTATE 1
#ifndef ioss_0_port_10_pin_4_HSIOM
    #define ioss_0_port_10_pin_4_HSIOM HSIOM_SEL_GPIO
#endif
#define Sensor3_HSIOM ioss_0_port_10_pin_4_HSIOM
#define Sensor3_IRQ ioss_interrupts_gpio_10_IRQn
#if defined (CY_USING_HAL)
    #define Sensor3_HAL_PORT_PIN P10_4
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Sensor3_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Sensor3_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Sensor3_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#endif //defined (CY_USING_HAL)
#define LED_BLUE_ENABLED 1U
#define LED_BLUE_PORT GPIO_PRT12
#define LED_BLUE_PORT_NUM 12U
#define LED_BLUE_PIN 4U
#define LED_BLUE_NUM 4U
#define LED_BLUE_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define LED_BLUE_INIT_DRIVESTATE 1
#ifndef ioss_0_port_12_pin_4_HSIOM
    #define ioss_0_port_12_pin_4_HSIOM HSIOM_SEL_GPIO
#endif
#define LED_BLUE_HSIOM ioss_0_port_12_pin_4_HSIOM
#define LED_BLUE_IRQ ioss_interrupts_gpio_12_IRQn
#if defined (CY_USING_HAL)
    #define LED_BLUE_HAL_PORT_PIN P12_4
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define LED_BLUE_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define LED_BLUE_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define LED_BLUE_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif //defined (CY_USING_HAL)
#define LED_RED_ENABLED 1U
#define LED_RED_PORT GPIO_PRT12
#define LED_RED_PORT_NUM 12U
#define LED_RED_PIN 5U
#define LED_RED_NUM 5U
#define LED_RED_DRIVEMODE CY_GPIO_DM_STRONG_IN_OFF
#define LED_RED_INIT_DRIVESTATE 1
#ifndef ioss_0_port_12_pin_5_HSIOM
    #define ioss_0_port_12_pin_5_HSIOM HSIOM_SEL_GPIO
#endif
#define LED_RED_HSIOM ioss_0_port_12_pin_5_HSIOM
#define LED_RED_IRQ ioss_interrupts_gpio_12_IRQn
#if defined (CY_USING_HAL)
    #define LED_RED_HAL_PORT_PIN P12_5
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define LED_RED_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define LED_RED_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define LED_RED_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_STRONG
#endif //defined (CY_USING_HAL)
#define Button1_ENABLED 1U
#define Button1_PORT GPIO_PRT9
#define Button1_PORT_NUM 9U
#define Button1_PIN 0U
#define Button1_NUM 0U
#define Button1_DRIVEMODE CY_GPIO_DM_PULLUP_IN_OFF
#define Button1_INIT_DRIVESTATE 1
#ifndef ioss_0_port_9_pin_0_HSIOM
    #define ioss_0_port_9_pin_0_HSIOM HSIOM_SEL_GPIO
#endif
#define Button1_HSIOM ioss_0_port_9_pin_0_HSIOM
#define Button1_IRQ ioss_interrupts_gpio_9_IRQn
#if defined (CY_USING_HAL)
    #define Button1_HAL_PORT_PIN P9_0
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Button1_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Button1_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Button1_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_PULLUP
#endif //defined (CY_USING_HAL)
#define Button2_ENABLED 1U
#define Button2_PORT GPIO_PRT9
#define Button2_PORT_NUM 9U
#define Button2_PIN 1U
#define Button2_NUM 1U
#define Button2_DRIVEMODE CY_GPIO_DM_PULLUP_IN_OFF
#define Button2_INIT_DRIVESTATE 1
#ifndef ioss_0_port_9_pin_1_HSIOM
    #define ioss_0_port_9_pin_1_HSIOM HSIOM_SEL_GPIO
#endif
#define Button2_HSIOM ioss_0_port_9_pin_1_HSIOM
#define Button2_IRQ ioss_interrupts_gpio_9_IRQn
#if defined (CY_USING_HAL)
    #define Button2_HAL_PORT_PIN P9_1
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Button2_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Button2_HAL_DIR CYHAL_GPIO_DIR_OUTPUT 
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Button2_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_PULLUP
#endif //defined (CY_USING_HAL)
#define Button3_ENABLED 1U
#define Button3_PORT GPIO_PRT9
#define Button3_PORT_NUM 9U
#define Button3_PIN 2U
#define Button3_NUM 2U
#define Button3_DRIVEMODE CY_GPIO_DM_ANALOG
#define Button3_INIT_DRIVESTATE 1
#ifndef ioss_0_port_9_pin_2_HSIOM
    #define ioss_0_port_9_pin_2_HSIOM HSIOM_SEL_GPIO
#endif
#define Button3_HSIOM ioss_0_port_9_pin_2_HSIOM
#define Button3_IRQ ioss_interrupts_gpio_9_IRQn
#if defined (CY_USING_HAL)
    #define Button3_HAL_PORT_PIN P9_2
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Button3_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Button3_HAL_DIR CYHAL_GPIO_DIR_INPUT 
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Button3_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_ANALOG
#endif //defined (CY_USING_HAL)
#define Button4_ENABLED 1U
#define Button4_PORT GPIO_PRT9
#define Button4_PORT_NUM 9U
#define Button4_PIN 3U
#define Button4_NUM 3U
#define Button4_DRIVEMODE CY_GPIO_DM_PULLUP
#define Button4_INIT_DRIVESTATE 1
#ifndef ioss_0_port_9_pin_3_HSIOM
    #define ioss_0_port_9_pin_3_HSIOM HSIOM_SEL_GPIO
#endif
#define Button4_HSIOM ioss_0_port_9_pin_3_HSIOM
#define Button4_IRQ ioss_interrupts_gpio_9_IRQn
#if defined (CY_USING_HAL)
    #define Button4_HAL_PORT_PIN P9_3
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Button4_HAL_IRQ CYHAL_GPIO_IRQ_NONE
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Button4_HAL_DIR CYHAL_GPIO_DIR_BIDIRECTIONAL 
#endif //defined (CY_USING_HAL)
#if defined (CY_USING_HAL)
    #define Button4_HAL_DRIVEMODE CYHAL_GPIO_DRIVE_PULLUP
#endif //defined (CY_USING_HAL)

extern const cy_stc_gpio_pin_config_t ioss_0_port_0_pin_0_config;
#if defined (CY_USING_HAL)
    extern const cyhal_resource_inst_t ioss_0_port_0_pin_0_obj;
#endif //defined (CY_USING_HAL)
extern const cy_stc_gpio_pin_config_t ioss_0_port_0_pin_1_config;
#if defined (CY_USING_HAL)
    extern const cyhal_resource_inst_t ioss_0_port_0_pin_1_obj;
#endif //defined (CY_USING_HAL)
extern const cy_stc_gpio_pin_config_t PIN_BUTTON_config;
#if defined (CY_USING_HAL)
    extern const cyhal_resource_inst_t PIN_BUTTON_obj;
#endif //defined (CY_USING_HAL)
extern const cy_stc_gpio_pin_config_t ioss_0_port_10_pin_0_config;
#if defined (CY_USING_HAL)
    extern const cyhal_resource_inst_t ioss_0_port_10_pin_0_obj;
#endif //defined (CY_USING_HAL)
extern const cy_stc_gpio_pin_config_t ioss_0_port_10_pin_1_config;
#if defined (CY_USING_HAL)
    extern const cyhal_resource_inst_t ioss_0_port_10_pin_1_obj;
#endif //defined (CY_USING_HAL)
extern const cy_stc_gpio_pin_config_t Sensor1_config;
#if defined (CY_USING_HAL)
    extern const cyhal_resource_inst_t Sensor1_obj;
#endif //defined (CY_USING_HAL)
extern const cy_stc_gpio_pin_config_t Sensor2_config;
#if defined (CY_USING_HAL)
    extern const cyhal_resource_inst_t Sensor2_obj;
#endif //defined (CY_USING_HAL)
extern const cy_stc_gpio_pin_config_t Sensor3_config;
#if defined (CY_USING_HAL)
    extern const cyhal_resource_inst_t Sensor3_obj;
#endif //defined (CY_USING_HAL)
extern const cy_stc_gpio_pin_config_t LED_BLUE_config;
#if defined (CY_USING_HAL)
    extern const cyhal_resource_inst_t LED_BLUE_obj;
#endif //defined (CY_USING_HAL)
extern const cy_stc_gpio_pin_config_t LED_RED_config;
#if defined (CY_USING_HAL)
    extern const cyhal_resource_inst_t LED_RED_obj;
#endif //defined (CY_USING_HAL)
extern const cy_stc_gpio_pin_config_t Button1_config;
#if defined (CY_USING_HAL)
    extern const cyhal_resource_inst_t Button1_obj;
#endif //defined (CY_USING_HAL)
extern const cy_stc_gpio_pin_config_t Button2_config;
#if defined (CY_USING_HAL)
    extern const cyhal_resource_inst_t Button2_obj;
#endif //defined (CY_USING_HAL)
extern const cy_stc_gpio_pin_config_t Button3_config;
#if defined (CY_USING_HAL)
    extern const cyhal_resource_inst_t Button3_obj;
#endif //defined (CY_USING_HAL)
extern const cy_stc_gpio_pin_config_t Button4_config;
#if defined (CY_USING_HAL)
    extern const cyhal_resource_inst_t Button4_obj;
#endif //defined (CY_USING_HAL)

void init_cycfg_pins(void);

#if defined(__cplusplus)
}
#endif


#endif /* CYCFG_PINS_H */
