/*******************************************************************************
* File Name: cycfg_routing.h
*
* Description:
* Establishes all necessary connections between hardware elements.
* This file was automatically generated and should not be modified.
* Tools Package 2.4.0.5972
* psoc6pdl 1.3.1.1499
* personalities 1.0.0.0
* udd 1.1.2.62
*
********************************************************************************
* Copyright 2022 Cypress Semiconductor Corporation (an Infineon company) or
* an affiliate of Cypress Semiconductor Corporation.
* SPDX-License-Identifier: Apache-2.0
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
********************************************************************************/

#if !defined(CYCFG_ROUTING_H)
#define CYCFG_ROUTING_H

#if defined(__cplusplus)
extern "C" {
#endif

#include "cycfg_notices.h"
void init_cycfg_routing(void);
#define init_cycfg_connectivity() init_cycfg_routing()
#define ioss_0_port_10_pin_0_HSIOM P10_0_SCB1_UART_RX
#define ioss_0_port_10_pin_1_HSIOM P10_1_SCB1_UART_TX
#define ioss_0_port_10_pin_2_ANALOG P10_2_PASS_SARMUX_PADS2
#define ioss_0_port_10_pin_3_ANALOG P10_3_PASS_SARMUX_PADS3
#define ioss_0_port_10_pin_4_ANALOG P10_4_PASS_SARMUX_PADS4

#if defined(__cplusplus)
}
#endif


#endif /* CYCFG_ROUTING_H */
