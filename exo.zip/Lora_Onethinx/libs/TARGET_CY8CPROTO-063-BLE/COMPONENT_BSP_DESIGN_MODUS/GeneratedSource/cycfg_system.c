/*******************************************************************************
* File Name: cycfg_system.c
*
* Description:
* System configuration
* This file was automatically generated and should not be modified.
* Tools Package 2.4.0.5972
* psoc6pdl 1.3.1.1499
* personalities 1.0.0.0
* udd 1.1.2.62
*
********************************************************************************
* Copyright 2022 Cypress Semiconductor Corporation (an Infineon company) or
* an affiliate of Cypress Semiconductor Corporation.
* SPDX-License-Identifier: Apache-2.0
*
* Licensed under the Apache License, Version 2.0 (the "License");
* you may not use this file except in compliance with the License.
* You may obtain a copy of the License at
*
*     http://www.apache.org/licenses/LICENSE-2.0
*
* Unless required by applicable law or agreed to in writing, software
* distributed under the License is distributed on an "AS IS" BASIS,
* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
* See the License for the specific language governing permissions and
* limitations under the License.
********************************************************************************/

#include "cycfg_system.h"

#define CY_CFG_SYSCLK_ALTHF_ENABLED 1
#define CY_CFG_SYSCLK_CLKHF0_ENABLED 1
#define CY_CFG_SYSCLK_CLKHF0_FREQ_MHZ 32UL
#define CY_CFG_SYSCLK_CLKHF0_CLKPATH CY_SYSCLK_CLKHF_IN_CLKPATH2
#define CY_CFG_SYSCLK_IMO_ENABLED 1
#define CY_CFG_SYSCLK_CLKPATH2_ENABLED 1
#define CY_CFG_SYSCLK_CLKPATH2_SOURCE CY_SYSCLK_CLKPATH_IN_ALTHF
#define CY_CFG_SYSCLK_CLKPERI_ENABLED 1
#define CY_CFG_PWR_ENABLED 1
#define CY_CFG_PWR_INIT 1
#define CY_CFG_PWR_USING_PMIC 0
#define CY_CFG_PWR_VBACKUP_USING_VDDD 1
#define CY_CFG_PWR_LDO_VOLTAGE CY_SYSPM_LDO_VOLTAGE_LP
#define CY_CFG_PWR_USING_ULP 0

#if defined (CY_USING_HAL)
    const cyhal_resource_inst_t srss_0_clock_0_pathmux_2_obj = 
    {
        .type = CYHAL_RSC_CLKPATH,
        .block_num = 2U,
        .channel_num = 0U,
    };
#endif //defined (CY_USING_HAL)

__STATIC_INLINE void Cy_SysClk_AltHfInit()
{
    cy_en_ble_eco_status_t status = Cy_BLE_EcoConfigure(CY_BLE_BLESS_ECO_FREQ_32MHZ, CY_BLE_SYS_ECO_CLK_DIV_1, 32U, 25U, CY_BLE_ECO_VOLTAGE_REG_AUTO);
    if ((CY_BLE_ECO_SUCCESS != status) && (CY_BLE_ECO_ALREADY_STARTED !=status))
    {
        cycfg_ClockStartupError(CY_CFG_SYSCLK_ALTHF_ERROR);
    }
}
__STATIC_INLINE void Cy_SysClk_ClkHf0Init()
{
    Cy_SysClk_ClkHfSetSource(0U, CY_CFG_SYSCLK_CLKHF0_CLKPATH);
    Cy_SysClk_ClkHfSetDivider(0U, CY_SYSCLK_CLKHF_NO_DIVIDE);
}
__STATIC_INLINE void Cy_SysClk_ClkPath2Init()
{
    Cy_SysClk_ClkPathSetSource(2U, CY_CFG_SYSCLK_CLKPATH2_SOURCE);
}
__STATIC_INLINE void Cy_SysClk_ClkPeriInit()
{
    Cy_SysClk_ClkPeriSetDivider(1U);
}
__STATIC_INLINE void init_cycfg_power(void)
{
     /* Reset the Backup domain on POR, XRES, BOD only if Backup domain is supplied by VDDD */
     #if (CY_CFG_PWR_VBACKUP_USING_VDDD)
     if (0u == Cy_SysLib_GetResetReason() /* POR, XRES, or BOD */)
     {
         Cy_SysLib_ResetBackupDomain();
         Cy_SysClk_IloDisable();
         Cy_SysClk_IloInit();
     }
     #else /* Dedicated Supply */
     Cy_SysPm_BackupSetSupply(CY_SYSPM_VDDBACKUP_VBACKUP);
     #endif /* CY_CFG_PWR_VBACKUP_USING_VDDD */

     /* Configure core regulator */
     #if CY_CFG_PWR_USING_LDO
     Cy_SysPm_LdoSetVoltage(CY_SYSPM_LDO_VOLTAGE_LP);
     Cy_SysPm_LdoSetMode(CY_SYSPM_LDO_MODE_NORMAL);
     #else
     Cy_SysPm_BuckEnable(CY_SYSPM_BUCK_OUT1_VOLTAGE_LP);
     #endif /* CY_CFG_PWR_USING_LDO */
     /* Configure PMIC */
     Cy_SysPm_UnlockPmic();
     #if CY_CFG_PWR_USING_PMIC
     Cy_SysPm_PmicEnableOutput();
     #else
     Cy_SysPm_PmicDisableOutput();
     #endif /* CY_CFG_PWR_USING_PMIC */
}


void init_cycfg_system(void)
{
#if defined (CY_USING_HAL)
    cyhal_hwmgr_reserve(&srss_0_clock_0_pathmux_2_obj);
#endif //defined (CY_USING_HAL)
}
